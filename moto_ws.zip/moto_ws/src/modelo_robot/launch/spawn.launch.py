import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration, FindPackageShare


def generate_launch_description():

    # Define arguments
    use_sim_time = LaunchConfiguration('use_sim_time')
    robot_name_in_model = 'moto_segmented.SLDASM'

    # Find paths to the package
    package_name = 'modelo_robot'
    pkg_share = FindPackageShare(package=package_name).find(package_name)

    # Get URDF file
    urdf_file_name = 'moto_segmented.SLDASM.urdf'
    urdf = os.path.join(
        get_package_share_directory('modelo_robot'),
        'urdf',
        urdf_file_name
    )

    # Read URDF file to get robot description
    with open(urdf, 'r') as infp:
        robot_desc = infp.read()

    robot_description = {"robot_description": robot_desc}

    # Node for spawning the robot in Gazebo
    spawn = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            "-topic", "/robot_description", 
            "-entity", robot_name_in_model,
            "-x", '0.0',
            "-y", '0.0',
            "-z", '0.05',
            "-Y", '0.0'
        ]
    )

    # Gazebo simulation launch
    gazebo = ExecuteProcess(
        cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_factory.so', 
             '-s', 'libgazebo_ros_init.so'], output='screen',
    )

    # Robot State Publisher node
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'use_sim_time': use_sim_time, 'robot_description': robot_desc}],
    )

    # Joint State Publisher node
    joint_state_publisher = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        parameters=[{'use_sim_time': use_sim_time}],
        name='joint_state_publisher',
    )

    return LaunchDescription([
        spawn,
        gazebo,
        robot_state_publisher_node,
        joint_state_publisher,
    ])

